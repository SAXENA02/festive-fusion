# FestiveFusion Shopping Website

## 🚀 Free Deployment Guide

### 1. Backend (Render)
- Go to https://render.com
- Create new Web Service → Connect to `backend` folder
- Add Env Variable: `MONGO_URI=your_mongo_connection_string`
- Deploy → Get link like: `https://festivefusion-backend.onrender.com`

### 2. Database (MongoDB Atlas)
- Sign up at https://www.mongodb.com/cloud/atlas
- Create free cluster
- Get connection string → Use in Render `MONGO_URI`

### 3. Frontend (Vercel)
- Go to https://vercel.com
- New Project → Import `frontend` folder
- Set Build Command: `npm run build`
- Set Output Directory: `build`
- Deploy → Get link like: `https://festivefusion.vercel.app`

### 4. Connect Frontend → Backend
In `Shop.jsx`, replace fetch URL with your Render backend:
```js
fetch("https://festivefusion-backend.onrender.com/api/products")
```

✅ Done! Your shopping site will be live on free domains.
