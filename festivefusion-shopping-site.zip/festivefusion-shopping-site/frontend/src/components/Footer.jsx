export default function Footer() {
  return (
    <footer style={{ textAlign: "center", padding: "10px", marginTop: "20px", background: "#f5f5f5" }}>
      <p>© 2025 FestiveFusion. All rights reserved.</p>
    </footer>
  );
}
