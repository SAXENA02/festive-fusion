export default function Checkout() {
  return (
    <div className="checkout">
      <h2>Complete Your Payment</h2>
      <p>Pay securely via UPI to confirm your order.</p>
      <img
        src="https://api.qrserver.com/v1/create-qr-code/?data=upi://pay?pa=9690123088@kotak811&pn=FestiveFusion&am=100&cu=INR"
        alt="UPI QR Code"
      />
      <p>Scan this QR or pay directly to <b>9690123088@kotak811</b></p>
    </div>
  );
}
