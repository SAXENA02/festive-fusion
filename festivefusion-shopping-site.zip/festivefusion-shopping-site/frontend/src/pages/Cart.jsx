export default function Cart() {
  return (
    <div className="cart">
      <h2>Your Cart 🛒</h2>
      <p>Cart functionality coming soon!</p>
    </div>
  );
}
