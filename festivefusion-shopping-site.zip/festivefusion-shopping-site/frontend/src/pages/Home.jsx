export default function Home() {
  return (
    <div className="home">
      <h1>Welcome to FestiveFusion 🎉</h1>
      <p>Your one-stop shop for festive hampers, God’s dresses & gifts.</p>
    </div>
  );
}
